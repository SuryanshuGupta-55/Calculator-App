package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    int diff=0;
    public void difference(int var1,int var2){
        diff=var1-var2;
    }
    public String SubResult(){
        return String.valueOf(diff);
    }
    // TODO -- start your code here
}
