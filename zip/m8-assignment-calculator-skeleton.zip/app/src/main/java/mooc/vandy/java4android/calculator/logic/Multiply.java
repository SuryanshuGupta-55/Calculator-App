package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Multiply operation.
 */
public class Multiply {
    int mul=1;
    public void multiply(int var1,int var2){
        mul=var1*var2;
    }
    public String MulResult(){
        return String.valueOf(mul);
    }
    // TODO -- start your code here
}
