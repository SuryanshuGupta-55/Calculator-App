package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
   int sum=0;
   public void Addition(int var1,int var2)
   {
       sum=var1+var2;
   }
   public String AddResult(){
       return String.valueOf(sum);
   }

    // TODO -- start your code here
}
